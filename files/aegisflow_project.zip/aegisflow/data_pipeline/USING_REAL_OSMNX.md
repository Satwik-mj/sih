# Using real OSMnx instead of the bundled extract

This project's sandbox had no network access to the Overpass API, so
`extract_osm_graph.py` reads a pre-downloaded `.osm` XML file instead of
calling OSMnx directly. On your own machine (or the hackathon judging
environment), you can swap in a live download in a few lines and skip
straight to a NetworkX/GraphML graph — no manual XML parsing needed.

```bash
pip install osmnx networkx
```

```python
import osmnx as ox

# pull a real city or neighborhood's drivable street network
G = ox.graph_from_place("Raichur, Karnataka, India", network_type="drive")

# add real edge speeds/travel times, falling back to class-based defaults
# exactly like extract_osm_graph.py does, but using OSMnx's own tables
G = ox.add_edge_speeds(G)
G = ox.add_edge_travel_times(G)

# export for the C++ simulator / this prototype's JSON format
ox.save_graphml(G, "city_graph.graphml")
gdf_nodes, gdf_edges = ox.graph_to_gdfs(G)
gdf_nodes.to_file("city_nodes.geojson", driver="GeoJSON")
gdf_edges.to_file("city_edges.geojson", driver="GeoJSON")
```

`G` is a `networkx.MultiDiGraph`: nodes keyed by real OSM node ID with
`x`/`y` (lon/lat), edges carrying `length`, `speed_kph`, `travel_time`,
`lanes`, `oneway`, `highway`, and `name` — the same fields
`extract_osm_graph.py` produces by hand from raw XML. Bounding-box
downloads (`ox.graph_from_bbox`) work the same way for a specific ward
or district instead of a whole place name.

For the DEM/flood side of AegisFlow, the equivalent real pipeline is:

```python
# a real elevation raster (e.g. CartoDEM, SRTM, or Bhuvan) clipped to
# the same bounding box as G, then sampled onto each node/edge
G = ox.elevation.add_node_elevations_raster(G, "dem_clip.tif")
G = ox.elevation.add_edge_grades(G)
```

Neither of these calls needs anything this prototype doesn't already
model conceptually (`add_edge_speeds`/`travel_times` ↔ this repo's
`attach_metadata()`; `add_node_elevations_raster` ↔ the procedural DEM
stand-in in `app/aegisflow_prototype.html`) — swapping them in is a
drop-in replacement, not a redesign.
