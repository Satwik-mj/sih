# AegisFlow — prototype code

Dynamic Hazard-Aware Evacuation Intelligence System, built for the SIH
2026 "Student Innovation / Disaster Management" submission by team
AK-SAAS. This folder is the browser-runnable prototype plus the real
OSM data-ingestion pipeline behind it — a stand-in for the proposed
Python/C++/PostGIS/Next.js stack, which can't run inside this sandbox.

## Structure

```
aegisflow/
├── app/
│   └── aegisflow_prototype.html   # the whole simulator: open this in a browser
└── data_pipeline/
    ├── West-Oakland.osm           # real, unaltered OpenStreetMap XML extract
    ├── extract_osm_graph.py       # parses it into a routable topological graph
    ├── oakland_graph.json         # that graph's output (embedded in the HTML)
    └── USING_REAL_OSMNX.md        # how to point this at a live OSMnx download instead
```

`app/aegisflow_prototype.html` is fully self-contained — no build step,
no server, no dependencies. Double-click it, or open it in any modern
browser.

## What's real vs. simulated

**Real:** the road graph. `West-Oakland.osm` is one of OSMnx's own
published test-fixture datasets (West Oakland, CA). `extract_osm_graph.py`
parses its raw `<node>`/`<way>` XML and simplifies it to an
intersections-only topological graph — 36 real intersections, 45 real
road segments — carrying each edge's real OSM name, length, highway
class, and (where tagged) speed limit, lane count and one-way
direction. This mirrors what `osmnx.graph_from_place(...)` +
`simplify_graph(...)` does; see `USING_REAL_OSMNX.md` for the three
lines that call OSMnx directly once you have live network access.

**Modeled, not measured:** road capacity (OSM has no vehicle-throughput
field, so capacity is assigned by road class using standard
traffic-engineering placeholders — replace with local data if you have
it), the flood/elevation grid (procedural, biased toward the real
Estuary-facing edge of this extract; real DEM ingestion needs the same
network access as the live OSM download), and ward/shelter locations
(role-assignments on top of real nodes; one shelter, Prescott School,
is a real OSM point of interest snapped to its nearest intersection).

**Not reproduced here:** the C++ routing kernel (the router in
`aegisflow_prototype.html` is JavaScript — a modified Dijkstra with a
BPR congestion term and a flood-depth penalty, same cost function the
proposal specifies, just not in C++), PostGIS storage, live IMD/CWC
telemetry feeds, and Docker offline packaging.

## Running the pipeline yourself

```bash
cd data_pipeline
python3 extract_osm_graph.py West-Oakland.osm oakland_graph.json
```

No third-party packages required — stdlib `xml.etree` and `math` only,
so it runs anywhere. The output JSON is what's embedded (inline, as a
`const GRAPH = {...}`) near the top of the `<script>` block in
`aegisflow_prototype.html`. To point the whole prototype at a different
place, regenerate `oakland_graph.json` from a different `.osm` extract
(or a live OSMnx download — see `USING_REAL_OSMNX.md`), then paste its
contents in place of the `GRAPH` constant. Node roles (which
intersections are wards vs. shelters) are set a few lines below that,
in a small `GRAPH.roles` map keyed by real OSM node ID.

## Data attribution

`West-Oakland.osm` is © OpenStreetMap contributors, distributed under
the Open Database License (ODbL), via OSMnx's public test-fixture
corpus (github.com/gboeing/osmnx).
